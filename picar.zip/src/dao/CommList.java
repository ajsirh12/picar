package dao;

public interface CommList {

}
