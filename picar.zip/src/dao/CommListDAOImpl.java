package dao;

public class CommListDAOImpl extends BaseDAO implements CommList {

}
