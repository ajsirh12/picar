package dao;

public interface RentInfoDAO {

}
