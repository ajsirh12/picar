package dao;

public interface QuestionDAO {

}
