package dao;

public class MemberGradeDAOImpl extends BaseDAO implements MemberGradeDAO {

}
