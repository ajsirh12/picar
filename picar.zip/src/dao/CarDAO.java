package dao;

public interface CarDAO {
	
}
