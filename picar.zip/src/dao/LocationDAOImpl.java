package dao;

public class LocationDAOImpl extends BaseDAO implements LocationDAO {

}
