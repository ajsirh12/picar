package dao;

public class CarDAOImpl extends BaseDAO implements CarDAO {

}
