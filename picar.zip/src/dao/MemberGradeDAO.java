package dao;

public interface MemberGradeDAO {

}
