package dao;

public class CarListDAOImpl extends BaseDAO implements CarListDAO {

}
