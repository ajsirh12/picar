package dao;

public class RentInfoDAOImpl extends BaseDAO implements RentInfoDAO {

}
