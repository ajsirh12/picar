package dao;

public class QuestionDAOImpl extends BaseDAO implements QuestionDAO {

}
