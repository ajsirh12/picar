package dao;

public interface CarListDAO {

}
