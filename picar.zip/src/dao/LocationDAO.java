package dao;

public interface LocationDAO {

}
