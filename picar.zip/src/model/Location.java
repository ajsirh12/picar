package model;

public class Location {
	private int carLoc;
	private String location;
}
